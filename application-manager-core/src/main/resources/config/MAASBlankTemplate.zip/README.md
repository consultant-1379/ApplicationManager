# Introduction

MAAS Application contains configuration files which are required to generate run StreamTerminator and EPS containers.


# Requirements

Please follow the documentation to set up the environment. It's recommended to use AIA sandbox for development and to test the flow.

# Folder structure

├── config
│   ├── config.properties
│   └── EsnLteRanParserPublisherDecoded_INTEGRATION_POINT.json
│   ├── EsnLteRanParserSubscriberRaw_INTEGRATION_POINT.json
│   ├── RAW_PUBLISHER_INTEGRATION_POINT.json
│   └── flow.xml    
├── maas-ui.json
├── pba.json
└── README.md


config folder contains the property files as following:
config.properties is used for identifying stream or file, selected parser/event types
RAW_PUBLISHER_INTEGRATION_POINT.json is used by stream terminator, topic name should match with esn subscriber topic name (output of stream terminator will be placed on Kafka as input of EPS)
EsnLteRanParserSubscriberRaw_INTEGRATION_POINT.json is used by EPS as configuration for Kafka input configuration
EsnLteRanParserPublisherDecoded_INTEGRATION_POINT.json is used by EPS as an output configuration, contains topic name (EPS processed data would be placed on this topic name)
pba.json contains the metadata of flow and would used by Deployment SDK


Based on your selection (standalone or distributed) you can run the following steps:
##TODO
