# Introduction

Copy data between Kafka and another system, instantiating Kafka Connectors for the systems they want to pull data from or push data to.

It uses AIA kafka-connect docker image, please refer to the documentation (http://analytics.ericsson.se/#/Documentation/kafka-connect-documentation) of kafka connect.

# Requirements

Please follow the documentation to set up the environment. It's recommended to use AIA sandbox for development and to test the flow.

# Folder structure

.
├── config
│   ├── ${fileName}.properties
│   └── kafka-connect-${deploymentMode}.properties
├── pba.json
└── README.md

config folder contains all the properties file.
${fileName}.properties is used for the data stream source/sink.
kafak-connect-${deploymentMode}.properties is used by kafka connect as configuration.
pbs.json contains the metadata of the flow and it will be used for deployment.

Based on your selection (standalone or distributed) you can run the following steps:

# Running in standalone mode

AIA Deployment SDK is under development. Please run the application using docker command in the server with http service,

```
sudo docker run -it --net host -v `pwd`/config:/tmp -v /var/log/httpd:/var/log/httpd armdocker.rnd.ericsson.se/aia/tooling/data-tools/kafka-connect:latest -mode=standalone /tmp/kafka-connect-standalone.properties /tmp/${fileName}.properties
```

# Running in distributed mode

AIA Deployment SDK is under development. Please run the application using docker command in the server with http service,

```
sudo docker run -it --net host -v `pwd`/config:/tmp -v /var/log/httpd:/var/log/httpd armdocker.rnd.ericsson.se/aia/tooling/data-tools/kafka-connect:latest /tmp/kafka-connect-distributed.properties /tmp/${fileName}.properties
```

# Verify output

The raw access log record will be added into kafka topic as defined in the properties file. You can use kafka console consumer to check the topic, e.g,

```
kafka-console-consumer --bootstrap-server localhost:9092 --topic <kafka topic>
<kafka topic>: the topic name is as defined in the properties file
```